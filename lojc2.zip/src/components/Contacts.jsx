import React from "react";
import Card from "./Card";
import Contacts from "./Contacts";

function Contacts() {
  return (
    <div>
      <h1>Wilkommen</h1>
      <h1>Kontakty</h1>
      <Card
        name={contacts[0].name}
        img={contacts[0].img}
        email={contacts[0].email}
        tel={contacts[0].tel}
        adresa={contacts[0].adresa}
      />
      <Card
        name={contacts[1].name}
        img={contacts[1].img}
        email={contacts[1].email}
        tel={contacts[1].tel}
        adresa={contacts[1].adresa}
      />
      <Card
        name={contacts[2].name}
        img={contacts[2].img}
        email={contacts[2].email}
        tel={contacts[2].tel}
        adresa={contacts[2].adresa}
      />
      <Card
        name={contacts[3].name}
        img={contacts[3].img}
        email={contacts[3].email}
        tel={contacts[3].tel}
        adresa={contacts[3].adresa}
      />
      <Card
        name={contacts[4].name}
        img={contacts[4].img}
        email={contacts[4].email}
        tel={contacts[4].tel}
        adresa={contacts[4].adresa}
      />
      <Card
        name={contacts[5].name}
        img={contacts[5].img}
        email={contacts[5].email}
        tel={contacts[5].tel}
        adresa={contacts[5].adresa}
      />
    </div>
  );
}

export default Contacts;
