.App {
  font-family: sans-serif;
  text-align: center;
}
