const contacts = [
  {
    id: 1,
    name: "Prokop Buben"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "prokop.jsemJaBuben@yahoo.es",
    tel: "987 654 321",
    adresa: "Kouřimská, Praha 6",
  },
  {
    id: 2,
    name: "Erik Spáčil"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "erik.spáčilRad@seznam.sk",
    tel: "666 666 666",
    adresa: "Tupolevcova, Letňany",
  },
  {
    id: 3,
    name: "Tomáš Jedno"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "tomas.jedno@gyarab.pl",
    tel: "696 969 696",
    adresa: "Svatodyndyjská, Praha 19",
  },
  {
    id: 4,
    name: "Jan Syreček"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "jeník.sejrýk@seznam.cz",
    tel: "545 558 669",
    adresa: "U sešlého žaludu, Spálená lhota",
  },
  {
    id: 5,
    name: "Kristýna Dozrálá"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "kristynka.selmicka@gmail.hr",
    tel: "215 585 645",
    adresa: "Veliká, Brno",
  },
  {
    id: 6,
    name: "Prokop Dveře"
    img: "https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.supraphon.cz%2Fpublic%2Fphoto%2F300x300%2Fe%2F2%2F5491.jpg%3F1562661744&imgrefurl=https%3A%2F%2Fwww.supraphon.cz%2Fnovinky%2F1304-karel-gott-80&tbnid=SDbVcKZbGnkgZM&vet=12ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ..i&docid=sUM_P9ACqQ72cM&w=300&h=300&q=karel%20gott&ved=2ahUKEwj5sPaWx93uAhUE_xoKHTDQCvkQMygBegUIARCxAQ",
    email: "prokop.jsemDvere@yahoo.uk",
    tel: " 602 548 815",
    adresa: "Boženy Němcové, Praha 5",
  }

];

export default contacts;